//number 1 greeting
function greetUgandan(name) {
console.log(`Hello ${name}, welcome to Uganda!`);
}
greetUgandan("samalie");


//task greet student

function greetStudent(name) {
    console.log(`Hello ${name}, you are attending the java script class.`);
}
greetStudent("Samalie");