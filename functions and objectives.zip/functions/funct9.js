//number 9 IIFE(Advanced)
(function () {
    console.log("This function runs immediately!");
    })();
    //task an IIFE printing a message
    (function() {
        console.log("Welcome to JavaScript in Uganda!");
    })();