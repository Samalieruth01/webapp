//number 1 introduction to objects
let objectName = {
    property1: 20000,
    property2: 50000,
    method1: function() {
    // method code
    }
};
