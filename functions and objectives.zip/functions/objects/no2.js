//task part 2 creating and accessing object properties(object for a ugandan farmer)
let ugandanFarmer = {
    name: "James",
    farmLocation: "Mbale",
    crop: "Coffee",
    numberOfAcres: 5
    };
    // Accessing properties
    console.log(`Farmer's Name: ${ugandanFarmer.name}`);
    console.log(`Farm Location: ${ugandanFarmer.farmLocation}`);


//task object school
const school = {
    name: "St julian high school Gayaza",
    location: "Mukono, Uganda",
    studentsCount: 2000,
    establishedYear: 1927
};
console.log("School Name:", school.name);
console.log("School Location:", school.location);