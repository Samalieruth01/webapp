//part 3 adding and modifying object properties
ugandanFarmer.cropsHarvested = 1000;
// Adding a new property
ugandanFarmer.crop = "Maize"; 
// Modifying an existing property
console.log(ugandanFarmer);


//task new property school type
constschool = {
    name: "St Julian high school Gayaza",
    location: "Kampala, Uganda",
    studentsCount: 5000,
    establishedYear: 2007,
    schoolType: "Secondary"
  };
  school.studentsCount = 2500;
  console.log(school);