export default () => (
	<main>
		<h1>Welcome to Next.js</h1>
	</main>
)
