const Depressioninput = document.getElementById("Depression-input");
const addTaskButton = document.getElementById("add-task-btn");this
const Depression = document.getElementById("Depresssion");

const addTask = ()=>{
    const taskText = todoInput.value.trim();
    if(taskText !== ""){
     const taskItem = createTaskItem(taskText)
        
    }
    
}
const createTaskItem = (taskText) => {
    const taskItem = document.createElement("li");
    taskItem.className ="Depression-item";
    
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.classList.add("Depression");

    const taskTextSpan = document.createElement("span");
    taskTextSpan.textContent = taskTex

    const deleteBtn = document.createElement("button");
    deleteBtn.textContent = "Delete";
    document.classList.add("delete-btn");
    deleteBtn.addEventListener("click",deleteTask);

    taskItem.appendChild(checkbox);
    taskItem.appendChild(taskTextSpan);
    taskItem.appendChild(deleteBtn);
    return taskItem;
   
}

const deleteTask = () => {
    const taskItem = event.target.parentNode;
    DepressioSn.removeChild(taskItem)
}
    

