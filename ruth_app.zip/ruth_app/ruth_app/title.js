function Title(props){
    return(
        <div>
            <h1>{props.heading}</h1>
            <h2>welcome to the{props.heading}</h2>
        </div>
    )
}
export default Title;